package model.shelves.criteria;


public abstract class CompoundCriteria implements Criterion {

	protected Criterion leftCriteria;
	protected Criterion rightCriteria;
	
	public CompoundCriteria(Criterion leftCriteria, Criterion rightCriteria) {
		this.leftCriteria = leftCriteria;
		this.rightCriteria = rightCriteria;
	}
}
