package model.shelves.criteria;

import model.rentals.Rental;

public class AuthorCriteria implements Criterion {

	private String author;

	public AuthorCriteria (String author) {
		this.author = author;
	}
	
	@Override
	public boolean satisfies(Rental rental) {
		return rental.getAuthor().equals(author) ;
	}

}
