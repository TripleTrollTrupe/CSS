package model.rentals;

@SuppressWarnings("serial")
public class NoSuchPageException extends Exception {

}
